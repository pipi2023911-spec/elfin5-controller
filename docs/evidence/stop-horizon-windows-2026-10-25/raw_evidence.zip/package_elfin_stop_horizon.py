"""归档本轮Windows真实测试和纯模型数据，保留失败日志，不生成ROS/真机结论。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import platform
import shutil
import subprocess
import sys
import zipfile

BASE = Path(__file__).resolve().parent.parent
REPO = BASE/'development/elfin5-qp-solver'
AUDIT = BASE/'audit'
OUT = REPO/'docs/evidence/stop-horizon-windows-2026-10-25'
OUT.mkdir(parents=True,exist_ok=True)
MODEL = AUDIT/'elfin-horizon-final-2026-10-25'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def save(path, obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

for name in ['comparison.csv','timer_horizon.csv','summary.json','horizon_comparison.png']:
    shutil.copy2(MODEL/name,OUT/name)
shutil.copy2(AUDIT/'elfin_simplification_checks_2026-10-25.json',OUT/'simplification_checks.json')
logs = ['elfin_stop_adapter_windows_2026-10-25.log','elfin_stop_adapter_windows_v2_2026-10-25.log',
        'elfin_stop_adapter_windows_final_2026-10-25.log','elfin_horizon_tests_2026-10-25.log',
        'elfin_horizon_tests_final_2026-10-25.log','elfin_horizon_study_2026-10-25.log',
        'elfin_stop_existing_offline_2026-10-25.log']
assert 'fresh' in (AUDIT/logs[0]).read_text(encoding='utf-8-sig')
assert '23 个stop场景、76 项断言' in (AUDIT/logs[2]).read_text(encoding='utf-8-sig')
assert 'FAILED (failures=1)' in (AUDIT/logs[3]).read_text(encoding='utf-8-sig')
assert 'Ran 4 tests' in (AUDIT/logs[4]).read_text(encoding='utf-8-sig')
assert 'Ran 14 tests' in (AUDIT/logs[6]).read_text(encoding='utf-8-sig')
manifest = {}
with zipfile.ZipFile(OUT/'raw_evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    files = [(p,'horizon/'+p.name) for p in sorted(MODEL.iterdir()) if p.is_file()]
    files += [(AUDIT/name,'logs/'+name) for name in logs]
    files += [(AUDIT/'check_elfin_simplifications.py','review/check_elfin_simplifications.py'),
              (AUDIT/'elfin_simplification_checks_2026-10-25.json','review/simplification_checks.json'),
              (AUDIT/'elfin5-review-2026-10-25/review_checks.json','review/previous_review_checks.json'),
              (Path(__file__).resolve(),'package_elfin_stop_horizon.py')]
    for path, member in files:
        z.write(path,member)
        manifest[member] = {'sha256':sha(path),'bytes':path.stat().st_size}
with zipfile.ZipFile(OUT/'raw_evidence.zip') as z:
    assert z.testzip() is None
save(OUT/'manifest.json',{'archive_sha256':sha(OUT/'raw_evidence.zip'),
                        'archive_bytes':(OUT/'raw_evidence.zip').stat().st_size,'members':manifest})
names = ['src/stop_hold_adapter_node.cpp','test/test_stop_hold_adapter.py',
         'scripts/validate_command_horizon.py','test/test_command_horizon.py',
         'launch/elfin5_stop_hold_adapter.launch','CMakeLists.txt']
model = read(MODEL/'summary.json')
preserved = read(OUT/'simplification_checks.json')['preserved_files']
for name,digest in preserved.items():
    assert sha(REPO/name)==digest
save(OUT/'verification.json',{
    'date':'2026-10-25','platform':platform.platform(),'python':sys.version.split()[0],
    'rospy_available_in_test_python':importlib.util.find_spec('rospy') is not None,
    'parent_commit':subprocess.check_output(['git','-c','safe.directory='+str(REPO),'rev-parse','HEAD'],cwd=REPO,text=True).strip(),
    'source_sha256':{name:sha(REPO/name) for name in names},
    'preserved_production_files_sha256':preserved,
    'stop':{'scenarios':23,'assertions':76,'compiler':'Windows现有Zig C++14；ROS接口桩',
            'production_parameters':{'still_velocity_rad_s':.005,'confirm_duration_s':.2,'confirm_timeout_s':1.,'feedback_timeout_s':.3},
            'first_fixture_failure_preserved':True},
    'horizon':{'model_unit_tests':4,'model_cases':model['cases'],'production_config_changed':False,
               'initial_incorrect_positive_stop_distance_assertion_preserved':True},
    'existing_offline_python_tests':14,
    'simplifications':'仅代数/源码审查，没有实施梯度、单次保持、居中或网关保护变更',
    'not_run':['完整ROS构建/接线','Gazebo','厂家驱动','EtherCAT通信','真实停车/使能'],
    'note':'原5mm容差、关节限制、QP求解器和100步预算保持不变；未向GitHub推送。'})
print(json.dumps({'archive_bytes':(OUT/'raw_evidence.zip').stat().st_size,'members':len(manifest),
                  'stop_scenarios':23,'horizon_cases':model['cases'],
                  'preserved_production_files':len(preserved)},ensure_ascii=False))
