"""独立审查简化的代数反例；不改控制器，不运行ROS或机械臂。"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import numpy as np

BASE = Path(__file__).resolve().parent.parent
REPO = BASE/'development/elfin5-qp-solver'
sys.path.insert(0,str(REPO/'scripts'))
from validate_command_horizon import sample

# 非奇异区ratio=0，梯度既不进入目标也不进入奇异半空间/停止条件。
warning, stop = .08,.015
gradient = np.array([.2,-.1,.3,0.,.1,-.2])
sigma_cases = []
for sigma in [.0,.015,.02,.05,.079,.08,.1]:
    ratio = np.clip((warning-sigma)/(warning-stop),0,1)
    optimized = gradient if sigma<warning else np.zeros(6)
    assert np.array_equal(ratio*gradient,ratio*optimized)
    assert (sigma<=stop and np.linalg.norm(gradient)<=1e-8) == (sigma<=stop and np.linalg.norm(optimized)<=1e-8)
    sigma_cases.append({'sigma':sigma,'same_weighted_gradient':True})

# 有限阻尼下的居中项不是严格零空间投影，关闭后XYZ可以变化。
J = np.zeros((3,6)); J[:,:3] = np.diag([1.,.5,.1])
lam = .0001
v = np.array([.01,0.,0.])
preferred = np.array([.1,-.1,.2,0.,0.,0.])
H = J.T@J+lam*np.eye(6)
with_center = np.linalg.solve(H,J.T@v+lam*preferred)
without_center = np.linalg.solve(H,J.T@v)
delta_xyz = J@(with_center-without_center)
assert np.linalg.norm(delta_xyz)>1e-6

# 端点/速度/跳变全部合法，插值内部仍可能越过位置和加速度上限。
segment = (0,140,.9995,.05,.9995,.05)
values = [sample(segment,t/10.) for t in range(1401)]
peak_position = max(x[0] for x in values)
assert peak_position>1.
assert abs(.9995-.9925)<.02 and .05<.0785
peak_accel = max(abs(values[i+1][1]-values[i][1])*10000 for i in range(len(values)-1))
assert peak_accel>.2512

unchanged = ['config/elfin5_qp_controller.yaml','config/elfin5_real_robot.yaml',
             'src_gazebo/box_qp_solver.cpp','src_gazebo/qp_cartesian_controller.cpp',
             'src/real_robot_bridge_node.cpp','src/real_robot_command_gate.cpp']
for name in unchanged:
    original = subprocess.check_output(['git','-c','safe.directory='+str(REPO),'show','ad25779:'+name],cwd=REPO)
    # 文本的工作区换行与Git可能不同；按UTF8规范化后比较内容。
    assert original.decode('utf-8').replace('\r\n','\n') == (REPO/name).read_text(encoding='utf-8').replace('\r\n','\n'), name
report = {'lazy_gradient_finite_algebra':sigma_cases,
          'centering_counterexample_delta_xyz':delta_xyz.tolist(),
          'centering_counterexample_norm':float(np.linalg.norm(delta_xyz)),
          'endpoint_checks_counterexample':{'start_desired':.9995,'measured_position':.9925,
               'endpoint':.9995,'velocity_start_end':.05,'horizon_s':.14,
               'position_upper':1.,'endpoint_step_limit':.02,'peak_position':peak_position,
               'peak_fd_acceleration_rad_s2':peak_accel,
               'note':'代数反例，不是实际机械臂或QP闭环试验'},
          'one_shot_hold_watchdog':{'timeout_s':.15,'silence_s':.16,'would_timeout':.16>.15,
                                  'note':'源码条件核对；未运行ROS集成'},
          'preserved_files':{name:hashlib.sha256((REPO/name).read_bytes()).hexdigest() for name in unchanged},
          'limits':'只做代数与源码核对，没有实施控制器或网关简化。'}
(BASE/'audit/elfin_simplification_checks_2026-10-25.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'algebra_cases':len(sigma_cases),'centering_delta_norm':report['centering_counterexample_norm'],
                  'endpoint_peak_position':peak_position,'endpoint_peak_acceleration':peak_accel,
                  'preserved_files':len(unchanged)},ensure_ascii=False))
