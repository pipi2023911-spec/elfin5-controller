"""整理真实参数核对、离线测试与编译失败记录，不产生仿真/真机结论。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

BASE = Path(__file__).resolve().parent.parent
REPO = BASE/'development/elfin5-qp-solver'
OUT = REPO/'docs/evidence/joint-limits-2026-10-25'
OUT.mkdir(parents=True, exist_ok=True)
VENDOR = Path(r'C:\Users\12503\Documents\xwechat_files\wxid_ehusgkcli1qw22_7663\msg\file\2026-09\机械臂项目\机械臂项目\elfin_robot-melodic_ethercat')
spec = importlib.util.spec_from_file_location('limits_test', REPO/'test/test_controller_limits.py')
test = importlib.util.module_from_spec(spec)
spec.loader.exec_module(test)
yaml = (REPO/'config/elfin5_qp_controller.yaml').read_text(encoding='utf-8')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, obj):
    (OUT/name).write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

urdf = VENDOR/'elfin_description/urdf/elfin5.urdf.xacro'
moveit = VENDOR/'elfin5_moveit_config/config/joint_limits.yaml'
joints = {}
for joint in ET.parse(urdf).getroot().iter('joint'):
    name = joint.get('name','')
    if name.startswith('elfin_joint') and name[-1:] in list('123456'):
        limit = joint.find('limit')
        joints[name] = {key: float(limit.get(key)) for key in ('lower','upper','velocity')}
assert len(joints) == 6, joints
rows = []
for i in range(6):
    name = f'elfin_joint{i+1}'
    limits = joints[name]
    lo = test.value(yaml,'joint_position_lower_limits')[i]
    hi = test.value(yaml,'joint_position_upper_limits')[i]
    vel = test.value(yaml,'joint_velocity_limits')[i]
    rows.append({'joint': name, 'handbook_90_position_rad': [lo,hi],
                 'handbook_90_position_deg': [math.degrees(lo),math.degrees(hi)],
                 'handbook_90_velocity_rad_s': vel,
                 'provided_legacy_urdf': limits,
                 'effective_position_rad_if_same_model': [max(lo,limits['lower']),min(hi,limits['upper'])],
                 'effective_velocity_rad_s_if_same_model': min(vel,limits['velocity']),
                 'qp_software_acceleration_rad_s2': 1., 'candidate_software_acceleration_rad_s2': .25})
save('limits.json', {'source': '用户提供的手册截图，未提供整本手册型号/版本页或额定加速度',
                    'urdf_sha256': sha(urdf), 'moveit_yaml_sha256': sha(moveit),
                    'screenshot_sha256': sha(REPO/'docs/elfin_joint_limits_reference.png'), 'joints': rows})
logs = ['elfin_joint_limits_test_2026-10-25.log',
        'elfin_joint_limits_compat_test_2026-10-25.log',
        'elfin_limits_offline_regression_2026-10-25.log']
failure = (BASE/'audit'/logs[0]).read_text(encoding='utf-8-sig')
passing = (BASE/'audit'/logs[1]).read_text(encoding='utf-8-sig')
offline = (BASE/'audit'/logs[2]).read_text(encoding='utf-8-sig')
assert 'no member named' in failure and 'CalledProcessError' in failure
assert '通过 64 项实际C++限值断言' in passing
assert 'Ran 14 tests' in offline and 'OK' in offline
with zipfile.ZipFile(OUT/'test_logs.zip','w',zipfile.ZIP_DEFLATED) as z:
    for log in logs:
        z.write(BASE/'audit'/log,log)
    z.write(Path(__file__).resolve(),'package_elfin_joint_limits.py')
with zipfile.ZipFile(OUT/'test_logs.zip') as z:
    assert z.testzip() is None
save('verification.json', {
    'date':'2026-10-25',
    'parent_commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
    'source_sha256': {name:sha(REPO/name) for name in ['src_gazebo/qp_cartesian_controller.cpp',
                      'test/test_controller_limits.py','config/elfin5_qp_controller.yaml',
                      'config/elfin5_real_robot.yaml','CMakeLists.txt']},
    'test_logs_zip': {'sha256':sha(OUT/'test_logs.zip'),'bytes':(OUT/'test_logs.zip').stat().st_size},
    'actual_test_results': {'cpp_limit_assertions':64,'existing_python_offline_tests':14,
                           'first_compile':'FAIL:旧Eigen3.3.4与本机新Clang模板解析不兼容',
                           'compat_compile':'PASS:测试Zig路径添加-fdelayed-template-parsing；保留第三方源码',
                           'ros_full_build':'未验证','gazebo_R1_R3':'未验证','hardware':'未验证'},
    'note':'手册90%配置与旧模型取交集；加速度为软件初值，网关仍默认关闭，未操作设备。'})
print(json.dumps({'rows':len(rows),'log_archive_bytes':(OUT/'test_logs.zip').stat().st_size,
                  'cpp_assertions':64,'python_tests':14},ensure_ascii=False))
