from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

audit=Path(__file__).resolve().parent
repo=audit.parent/'development/elfin5-qp-solver'
out=repo/'docs/debug/horizon-coverage-2026-10-27'
model=audit/'horizon-fixed140-2026-10-27'
baseline=json.loads((out/'baseline_manifest.json').read_text(encoding='utf-8'))
vendor=Path(r'C:\Users\12503\Documents\xwechat_files\wxid_ehusgkcli1qw22_7663\msg\file\2026-09\机械臂项目\机械臂项目\elfin_robot-melodic_ethercat')
for name,digest in baseline['unchanged_qp_files_sha256'].items():
    assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
for name,digest in baseline['unchanged_vendor_files_sha256'].items():
    assert hashlib.sha256((vendor/name).read_bytes()).hexdigest()==digest,name
for name in ['comparison.csv','horizon_comparison.png']:
    shutil.copyfile(model/name,out/name)
logs=['horizon_fixed140_initial.log','horizon_fixed140_cpp.log','horizon_fixed140_model_tests.log',
      'horizon_fixed140_existing_offline.log','horizon_fixed140_model_run.log']
assert '144' in (audit/logs[1]).read_text(encoding='utf-8-sig')
assert 'Ran 4 tests' in (audit/logs[2]).read_text(encoding='utf-8-sig')
assert 'Ran 14 tests' in (audit/logs[3]).read_text(encoding='utf-8-sig')
members={}
with zipfile.ZipFile(out/'raw_evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    def add(name,data):
        z.writestr(name,data);members[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
    for p in sorted(model.iterdir()):
        if p.is_file():add('model/'+p.name,p.read_bytes())
    for name in logs:add('logs/'+name,(audit/name).read_bytes())
    for name in ['test/test_qp_command_horizon.py','test/test_command_horizon.py','scripts/validate_command_horizon.py']:
        add('reproduction/'+name,(repo/name).read_bytes())
    add('reproduction/package_horizon_fix.py',Path(__file__).read_bytes())
files=['config/elfin5_qp_controller.yaml','src_gazebo/qp_cartesian_controller.cpp',
       'include/elfin5_qp_controller/qp_cartesian_controller.h','CMakeLists.txt','test/test_qp_command_horizon.py']
verification={'date':'2026-10-27','parent_commit':baseline['baseline_commit'],
 'current_source_sha256':{p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in files},
 'unchanged_qp_files_sha256':baseline['unchanged_qp_files_sha256'],
 'unchanged_vendor_files_sha256':baseline['unchanged_vendor_files_sha256'],
 'cpp_method_assertions':144,'horizon_model_tests':4,'existing_offline_tests':14,'model_cases':21,
 'fixed_horizon_s':.14,'control_rate_hz':50,'goal_tolerance_m':.005,'solver_iteration_budget':100,
 'baseline_archive_sha256':hashlib.sha256((out/'baseline_50ms.zip').read_bytes()).hexdigest(),
 'archive_sha256':hashlib.sha256((out/'raw_evidence.zip').read_bytes()).hexdigest(),'members':members,
 'not_run':['完整ROS/MoveIt节点构建','Gazebo','EtherCAT','真机停车/运动'],
 'note':'140ms代码适配与Windows方法/模型验证；不宣称真机抖动已经消除'}
(out/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for archive,manifest in [(out/'baseline_50ms.zip',baseline),(out/'raw_evidence.zip',verification)]:
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive_sha256']
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(manifest['members'])
        for name,info in manifest['members'].items():assert hashlib.sha256(z.read(name)).hexdigest()==info['sha256']
for p in [repo/'README.md',repo/'docs/interfaces.md',repo/'docs/usage.md',repo/'docs/testing.md',
          repo/'docs/horizon_validation.md',repo/'docs/debug_history.md',out/'README.md']:
    text=p.read_text(encoding='utf-8');assert '\ufffd' not in text
    for target in re.findall(r'\]\(([^)]+)\)',text):
        if not target.startswith(('https:','http:','#')):assert (p.parent/target.split('#')[0]).exists(),(p,target)
git=['git','-c','safe.directory='+str(repo),'-C',str(repo)]
assert subprocess.check_output(git+['rev-parse',baseline['baseline_tag']+'^{}'],text=True).strip()==baseline['baseline_commit']
subprocess.check_call(git+['diff','--check'])
print(json.dumps({'passed':True,'baseline_members':len(baseline['members']),'evidence_members':len(members),
 'unchanged_vendor_files':len(baseline['unchanged_vendor_files_sha256']),
 'unchanged_qp_files':len(baseline['unchanged_qp_files_sha256']),'documents_checked':7},ensure_ascii=False))
