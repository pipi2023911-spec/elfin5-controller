# TASK_RESULT｜QP求解器修复

- 目标：先修Elfin5，不同时修改Panda/Dummy；README和docs保持统一模板风格。
- 基线：96484d60cd7eece54a86f2cb739cd25e3246f861。
- 交付：main提交ad25779ea3e66696fa69e7a2b4fc2e33f71ae1de，14个文件。普通快进推送成功，已核对远程main和关键文件Git blob。
- 本地工程：development/elfin5-qp-solver，工作区干净；厂家源码和其他仓库未修改。

## 实际修改
1. 有效集盒QP、归一化单半空间、区间保护乘子搜索；全部子问题共享总迭代预算。
2. 正确处理零法向、约束缩放、固定变量及数值/预算失败；可行与KKT收敛分开，solve接口不变。
3. 修复Eigen::Vector2d*无法传给VectorXd*的真实gtest编译问题。
4. 固定2000例及元信息、40项解析断言、独立可行性/双向目标差/KKT回归、新seed生成器、损坏文件误通过防护及CMake注册。
5. README全文件说明；docs/interfaces、usage、testing同步更新；新增docs/qp_solver.md。文档无变更历史段落，保留仿真/真机证据边界。

## 实际测试
- Windows/Zig0.16.0，C++14/O2，Eigen3.4.1：固定2000及seed43新2000通过，均0失败、0未收敛；独立KKT/目标/原约束通过。
- 相同求解器使用Eigen3.3.4重新编译：上述两组均通过。旧Eigen与本机Clang模板解析冲突，使用-fdelayed-template-parsing兼容参数后通过；未修改第三方头文件。初次失败保留qp_eigen334_build.log，不将该参数列为Ubuntu/GCC要求。
- 真实GoogleTest1.8.1，编译、链接和运行10项通过，Eigen3.4.1/3.3.4分别检查。
- 10项文件契约检查通过：缺失、空、截断、非有限、额外字段、数量及参数错误不能报告PASS。
- 14项既有Python离线检查通过；8个Python文件语法、5个XML、README文件覆盖及相对链接、git diff检查通过。
- 网关和控制器数学逻辑未修改，未扩大到E2诊断/MuJoCo/Dummy。

## 命令与日志
在Ubuntu仓库根目录的可复现命令：

```bash
g++ -std=c++14 -O2 -Wall -Wextra -Wpedantic -I include -isystem /usr/include/eigen3 src_gazebo/box_qp_solver.cpp test/test_box_qp_standalone.cpp -o /tmp/elfin5_qp_test
/tmp/elfin5_qp_test test/qp_reference_cases.txt 2000
python3 test/test_qp_input_files.py /tmp/elfin5_qp_test
python3 scripts/gen_qp_reference_cases.py --seed 43 --count 2000 --output /tmp/elfin5_seed43.txt
/tmp/elfin5_qp_test /tmp/elfin5_seed43.txt 2000
```

本机实际使用上述相同源码和参数的Zig C++编译器、工作区Eigen路径；真实gtest还直接编译gtest-all.cc/gtest_main.cc并链接。
原始日志：qp_final_build.log、qp_final_2000.log、qp_final_seed43.log、qp_gtest.log、qp_eigen334_compat_build.log、qp_eigen334_2000.log、qp_eigen334_seed43.log、qp_gtest334.log、qp_file_contract334.log、qp_seed43_generation.log。本次开发机时间测量仅为样本统计，不是硬实时最坏上限。

## 未验证及下一步
- Ubuntu/GCC完整catkin、ROS接线、Gazebo R1–R9和真机：未验证。无机器人实验曲线。
- 先在Ubuntu独立回归/真实catkin测试，再跑R1、R1–R3及R1–R9重复实验。记录关节居中/奇异区行为；准确解可能改变轨迹，不先改增益去迎合旧结果。
- 诊断兼容字段projected_gradient_norm已在文档明确为归一化KKT残差，不与旧投影梯度残差直接比较。上层QP_INFEASIBLE仍是通用失败状态，message区分具体原因。
- 默认真机准入和停止保护保持原样；本交付不等于授权或完成真机运动。
- 后续Panda/Dummy按同一README/文档结构分别处理，不在本轮同时修改。
